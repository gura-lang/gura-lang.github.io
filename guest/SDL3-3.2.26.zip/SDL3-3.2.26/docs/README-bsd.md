# FreeBSD / OpenBSD / NetBSD

SDL is fully supported on BSD platforms, and is built using [CMake](README-cmake.md).

If you want to run on the console, you can take a look at [KMSDRM support on BSD](README-kmsbsd.md)

