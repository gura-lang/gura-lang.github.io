Support for the Nokia N-Gage has been removed from SDL3 (but will make a
comeback when newer compilers are available for the platform).

SDL2 still supports this platform.

